from distutils.core import setup
import py2exe

setup(windows = ["Exemple_1.py"])
