#! /usr/bin/env python
# -*- coding: Latin-1 -*-

def volBoite(x1, x2, x3):
    "Volume d'une bo�te parall�lipip�dique"
    return x1 * x2 * x3

# test :
print volBoite(5.2, 7.7, 3.3)
