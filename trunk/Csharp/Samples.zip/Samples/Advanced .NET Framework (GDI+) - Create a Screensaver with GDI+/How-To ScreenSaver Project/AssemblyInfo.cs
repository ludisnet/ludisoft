using System;
using System.Reflection;
using System.Runtime.InteropServices;
// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
// Review the values of the assembly attributes

[assembly: AssemblyTitle("")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: CLSCompliant(true)]

//The following GUID is for the ID of the typelib if this project is exposed to COM

[assembly: Guid("51BFD488-5963-4179-9E73-C8A18CFA8C9B")]
// Version information for an assembly consists of the following four values:
//
//      Major Version

//      Minor Version
 
//      Build Number

//      Revision

//Version


// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' shown below:
[assembly: AssemblyVersion("1.0.*")]

