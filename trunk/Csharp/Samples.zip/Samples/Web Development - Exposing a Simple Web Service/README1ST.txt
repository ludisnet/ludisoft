
Navigate to the Web Sites folder and 2x click the setup.vbs script.  Click OK to all prompts.

Next Open up the VB.NET How-To Build Web Services Client Solution.

If you have accidently opened the solution already and recieved errors when 
opening the web sites you can simply right click each web project and choose 
reload web project after running the script.

The setup.vbs assumes that your default web site is located at c:\inetpub\wwwroot.

If this is not the case Modify setup.vbs so that it copies the files to your default web 
site location.

Further information about this sample is contained in the readme.htm file in the 
HowToBuildWebServices Solution.

