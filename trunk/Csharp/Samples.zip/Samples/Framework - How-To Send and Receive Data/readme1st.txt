To install the web site double-click the Setup.vbs script.
Then open the Solution File. Follow the directions in the ReadMe.htm file to configure the security settings
on the virtual folder created by Setup.vbs.
Press F5 to run the application.

The setup.vbs assumes that your default web site is located at c:\inetpub\wwwroot. If this is not the case 
Modify setup.vbs so that it copies the files to your default web site location.