To install the web site 2x click the Setup.vbs script.
Then open the Solution File.
Press F5 to run the solution.

The setup.vbs assumes that your default web site is located at c:\inetpub\wwwroot.

If this is not the case Modify setup.vbs so that it copies the files to your default web 
site location.