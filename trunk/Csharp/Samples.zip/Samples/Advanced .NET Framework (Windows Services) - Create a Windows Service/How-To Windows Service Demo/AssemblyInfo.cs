
using System.Reflection;
using System.Runtime.InteropServices;
// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.

using System;
// Review the values of the assembly attributes

[assembly: AssemblyTitle("C# How-To: Creating a Windows Service - Demo")]
[assembly: AssemblyDescription("C# How-To: Creating a Windows Service - Demo")]
[assembly: AssemblyCompany("Microsoft Corporation")]
[assembly: AssemblyProduct("Microsoft C# How To: 2002")]
[assembly: AssemblyCopyright("Copyright  2002 Microsoft Corporation.  All rights reserved.")]
[assembly: CLSCompliant(true)]
//The following GUID is for the ID of the typelib if this project is exposed to COM

[assembly: Guid("F8A41963-88C8-44AE-9194-38AA35BC58ED")]
// Version information for an assembly consists of the following four values:
//
//      Major Version

//      Minor Version
 
//      Build Number

//      Revision

//Version


// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' shown below:
[assembly: AssemblyVersion("1.0.0.0")]

