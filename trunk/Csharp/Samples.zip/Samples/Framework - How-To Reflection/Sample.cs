//Copyright (C) 2002 Microsoft Corporation
//All rights reserved.
//THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER 
//EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF 
//MERCHANTIBILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
//Requires the Trial or Release version of Visual Studio .NET Professional (or greater).

public class Sample
{
	//This class is merely here to be reflected against. It is completely unused 
	//in the application other than being made available as an example type 
	//for reflection. View its metadata by selecting the 'VB.Net How-To Reflection'
	//assembly when selecting a loaded assembly.

	public int x;
	protected long y;
	private short z;

	public void Method1(int i)
	{

	}

	public void Method2()
	{
	}

	public string Method3() 
	{
		return string.Empty;
	}

	private void Method4()
	{
	}
}
