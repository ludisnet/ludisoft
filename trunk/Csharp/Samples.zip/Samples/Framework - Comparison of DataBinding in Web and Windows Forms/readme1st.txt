Navigate to the Web App folder and 2x click the setup.vbs script.  Click OK to all prompts.

If you have accidently opened the solution already and recieved errors when 
opening the web sites you can simply right click each web project and choose 
reload web project after running the script.

Further information about this sample is contained in the readme.htm file.

