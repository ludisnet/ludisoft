using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.ComponentModel;
using System.Windows.Forms;

namespace LudiProgressBar
{
	/// <summary>G�re une barre de progression</summary>
	[ToolboxBitmap( typeof( LudiProgressBar ), "ToolboxBitmap.bmp" ), DefaultProperty( "Value" )]
	public class LudiProgressBar : UserControl
	{
		#region Variables priv�es
		// Couleur de la bordure
		private Color _borderColor;

		// Style de bordure du contr�le
		private BorderStyle _borderStyle;

		// Largeur de la bordure
		private int _borderWidth;

		// Couleurs de d�but et de fin de d�grad� du fond du contr�le
		private Color _backStartColor;
		private Color _backEndColor;

		// Angle du d�grad� du fond du contr�le
		private float _backColorGradientAngle;

		// Texte inscrit au centre du contr�le
		private string _progressBarText;

		// Couleurs du texte avant et apr�s le passage de la barre de progression
		private Color _textColorBefore;
		private Color _textColorAfter;

		// Couleur de la barre de progression
		private Color _progressBarColor;

		// Opacit� de la barre de progression ( 0-Transparente, 255-Opaque )
		private int _progressBarOpacity;

		// Valeurs minimale et maximale
		private int _minValue;
		private int _maxValue;

		// Valeur de la barre de progression
		private int _value;
		#endregion

		/// <summary>Constructeur</summary>
		public LudiProgressBar()
		{
			// Affecte les valeur par d�faut aux variables priv�es
			_value = 0;
			_minValue = 0;
			_maxValue = 100;

			_backStartColor = Color.White;
			_backEndColor = SystemColors.Control;
			_backColorGradientAngle = 45f;

			_borderStyle = BorderStyle.FixedSingle;
			_borderColor = Color.Black;

			_progressBarColor = Color.Black;
			_progressBarOpacity = 80;

			_progressBarText = "";
			_textColorBefore = SystemColors.ControlDark;
			_textColorAfter = SystemColors.Control;

			// Initialise le style du contr�le
			SetStyle( ControlStyles.DoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint, true );
		}

		#region Gestion de l'apparence du contr�le
		/// <summary>Le contr�le doit �tre redessin�</summary>
		/// <param name="e">Arguments de l'�v�nement</param>
		protected override void OnPaint( PaintEventArgs e )
		{
			// Dessine le fond du contr�le
			DrawBackground( e );

			// Dessine la barre de progression
			DrawProgressBar( e );

			// Dessine le texte du contr�le
			DrawText( e );

			// Dessine les bordures du contr�le
			DrawBorder( e );

			// Fait appel � la m�thode de base
			base.OnPaint( e );
		}

		// Dessine le fond du contr�le
		private void DrawBackground( PaintEventArgs e )
		{
			LinearGradientBrush brush = new LinearGradientBrush( new Rectangle( 0, 0, Width, Height ), _backStartColor, _backEndColor, _backColorGradientAngle, true );
			e.Graphics.FillRectangle( brush, 0, 0, Width, Height );
		}

		// Dessine la barre de progression
		private void DrawProgressBar( PaintEventArgs e )
		{
			Color progressBarColor = Color.FromArgb( _progressBarOpacity, _progressBarColor.R, _progressBarColor.G, _progressBarColor.B );
			e.Graphics.FillRectangle( new Pen( progressBarColor ).Brush, GetProgressBounds() );
		}

		// Dessine le texte du contr�le
		private void DrawText( PaintEventArgs e )
		{
			// Aucun texte ne doit �tre dessin�
			if( _progressBarText == null || _progressBarText.Length == 0 )
				return;

			// R�cup�re les dimensions du texte
			SizeF stringSize = e.Graphics.MeasureString( _progressBarText, Font );

			// Calcul les position du texte dans le contr�le
			int stringLeft = ( stringSize.Width > Width ? _borderWidth + 1 : (int)( ( Width - stringSize.Width ) / 2 ) );
			int stringTop = ( stringSize.Height > Height ? _borderWidth + 1 : (int)( ( Height - stringSize.Height ) / 2 ) );

			// Dessine le texte situ� en dessous de la barre de progression
			e.Graphics.DrawString( _progressBarText, Font, new Pen( _textColorBefore ).Brush, stringLeft, stringTop );

			// Dessine le texte situ� au-dessus de la barre de progression
			e.Graphics.Clip = new Region( GetProgressBounds() );
			e.Graphics.DrawString( _progressBarText, Font, new Pen( _textColorAfter ).Brush, stringLeft, stringTop );
			e.Graphics.Clip = new Region( new Rectangle( 0, 0, Width, Height ) );
		}

		// Dessine les bordures du contr�le
		private void DrawBorder( PaintEventArgs e )
		{
			// D'apr�s le style de bordure
			switch( _borderStyle )
			{
				case BorderStyle.FixedSingle :

					e.Graphics.DrawRectangle( new Pen( _borderColor ), 0, 0, Width - 1, Height - 1 );
					break;

				case BorderStyle.Fixed3D :

					e.Graphics.DrawLine( new Pen( _borderColor ), 0, 0, Width - 1, 0 );
					e.Graphics.DrawLine( new Pen( _borderColor ), 0, 0, 0, Height - 1 );
					e.Graphics.DrawLine( new Pen( ControlPaint.LightLight( _borderColor ) ), Width - 1, 1, Width - 1, Height - 1 );
					e.Graphics.DrawLine( new Pen( ControlPaint.LightLight( _borderColor ) ), 1, Height - 1, Width - 1, Height - 1 );
					break;
			}
		}
		#endregion

		#region M�thode priv�e
		// Retourne un rectangle repr�sentant la barre de progression
		private Rectangle GetProgressBounds()
		{
			int path = _maxValue - _minValue;
			int currentValue = _value - _minValue;

			return new Rectangle( _borderWidth + 1, _borderWidth + 1, (int)( (float)( currentValue ) / path * ( Width - 2 * ( _borderWidth + 1 ) ) ), Height - 2 * ( _borderWidth + 1 ) );
		}
		#endregion

		#region Propri�t�s
		[Category( "Apparence" ), Description( "Obtient ou d�fini la couleur de la bordure" )]
		/// <summary>Obtient ou d�fini la couleur de la bordure</summary>
		public Color BorderColor
		{
			get{ return _borderColor; }
			set
			{
				// M�morise la nouvelle valeur
				_borderColor = value;

				// Redessine le contr�le
				Invalidate( true );
			}
		}

		[Category( "Apparence" ), Description( "Obtient ou d�fini le style de bordure" )]
		/// <summary>Obtient ou d�fini le style de bordure</summary>
		public BorderStyle BorderStyle
		{
			get{ return _borderStyle; }
			set
			{
				// M�morise la nouvelle valeur
				_borderStyle = value;

				// Calcule l'�paisseur de la bordure
				_borderWidth = ( _borderStyle == BorderStyle.None ) ? 0 : 1;

				// Redessine le contr�le
				Invalidate( true );
			}
		}

		[Category( "Apparence" ), Description( "Obtient ou d�fini la couleur de d�but de d�grad� du fond du contr�le" )]
		/// <summary>Obtient ou d�fini la couleur de d�but de d�grad� du fond du contr�le</summary>
		public Color BackStartColor
		{
			get{ return _backStartColor; }
			set
			{
				// M�morise la nouvelle valeur
				_backStartColor = value;

				// Redessine le contr�le
				Invalidate( true );
			}
		}

		[Category( "Apparence" ), Description( "Obtient ou d�fini la couleur de fin de d�grad� du fond du contr�le" )]
		/// <summary>Obtient ou d�fini la couleur de fin de d�grad� du fond du contr�le</summary>
		public Color BackEndColor
		{
			get{ return _backEndColor; }
			set
			{
				// M�morise la nouvelle valeur
				_backEndColor = value;

				// Redessine le contr�le
				Invalidate( true );
			}
		}

		[Category( "Apparence" ), Description( "Obtient ou d�fini l'angle de d�grad� du fond du contr�le" )]
		/// <summary>Obtient ou d�fini l'angle de d�grad� du fond du contr�le</summary>
		public float BackColorGradientAngle
		{
			get{ return _backColorGradientAngle; }
			set
			{
				// M�morise la nouvelle valeur
				_backColorGradientAngle = value;

				// Redessine le contr�le
				Invalidate( true );
			}
		}

		[Category( "Apparence" ), Description( "Obtient ou d�fini le texte situ� au centre du contr�le" )]
		/// <summary>Obtient ou d�fini le texte situ� au centre du contr�le</summary>
		public string ProgressBarText
		{
			get{ return _progressBarText; }
			set
			{
				// M�morise la nouvelle valeur
				_progressBarText = value;

				// Redessine le contr�le
				Invalidate( true );
			}
		}

		[Category( "Apparence" ), Description( "Obtient ou d�fini la couleur du texte avant le passage de la barre de progression" )]
		/// <summary>Obtient ou d�fini la couleur du texte avant le passage de la barre de progression</summary>
		public Color TextColorBefore
		{
			get{ return _textColorBefore; }
			set
			{
				// M�morise la nouvelle valeur
				_textColorBefore = value;

				// Redessine le contr�le
				Invalidate( true );
			}
		}

		[Category( "Apparence" ), Description( "Obtient ou d�fini la couleur du texte apr�s le passage de la barre de progression" )]
		/// <summary>Obtient ou d�fini la couleur du texte apr�s le passage de la barre de progression</summary>
		public Color TextColorAfter
		{
			get{ return _textColorAfter; }
			set
			{
				// M�morise la nouvelle valeur
				_textColorAfter = value;

				// Redessine le contr�le
				Invalidate( true );
			}
		}

		[Category( "Apparence" ), Description( "Obtient ou d�fini la couleur de la barre de progression" )]
		/// <summary>Obtient ou d�fini la couleur de la barre de progression</summary>
		public Color ProgressBarColor
		{
			get{ return _progressBarColor; }
			set
			{
				// M�morise la nouvelle valeur
				_progressBarColor = value;

				// Redessine le contr�le
				Invalidate( true );
			}
		}

		[Category( "Apparence" ), Description( "Obtient ou d�fini l'opacit� de la barre de progression (0-Transparente, 255-Opaque)" )]
		/// <summary>Obtient ou d�fini l'opacit� de la barre de progression (0-Transparente, 255-Opaque)</summary>
		public int ProgressBarOpacity
		{
			get{ return _progressBarOpacity; }
			set
			{
				// M�morise la nouvelle valeur
				_progressBarOpacity = value;

				// La nouvelle valeur est trop petite
				if( _progressBarOpacity < 0 )
					_progressBarOpacity = 0;

				// La nouvelle valeur est trop grande
				if( _progressBarOpacity > 255 )
					_progressBarOpacity = 255;

				// Redessine le contr�le
				Invalidate( true );
			}
		}

		[Category( "Value" ), Description( "Obtient ou d�fini la valeur minimale de la barre de progression" )]
		/// <summary>Obtient ou d�fini la valeur minimale de la barre de progression</summary>
		public int MinValue
		{
			get{ return _minValue; }
			set
			{
				// M�morise la nouvelle valeur
				_minValue = value;

				// Emp�che la valeur d'�tre inf�rieur � la valeur minimale
				if( _value < _minValue )
					_value = _minValue;

				// Redessine le contr�le
				Invalidate( true );
			}
		}

		[Category( "Value" ), Description( "Obtient ou d�fini la valeur maximale de la barre de progression" )]
		/// <summary>Obtient ou d�fini la valeur maximale de la barre de progression</summary>
		public int MaxValue
		{
			get{ return _maxValue; }
			set
			{
				// M�morise la nouvelle valeur
				_maxValue = value;

				// Emp�che la valeur d'�tre sup�rieur � la valeur maximale
				if( _value > _maxValue )
					_value = _maxValue;

				// Redessine le contr�le
				Invalidate( true );
			}
		}

		[Category( "Value" ), Description( "Obtient ou d�fini la valeur de la barre de progression" )]
		/// <summary>Obtient ou d�fini la valeur de la barre de progression</summary>
		public int Value
		{
			get{ return _value; }
			set
			{
				// M�morise la nouvelle valeur
				_value = value;

				// Emp�che la valeur d'�tre inf�rieur � la valeur minimale
				if( _value < _minValue )
					_value = _minValue;

				// Emp�che la valeur d'�tre sup�rieur � la valeur maximale
				if( _value > _maxValue )
					_value = _maxValue;

				// Redessine le contr�le
				Invalidate( true );
			}
		}
		#endregion

		#region Propri�t�s modifi�es
		[Browsable( false )]
		/// <summary>Obtient ou d�fini la couleur de fond du contr�le (obsol�te)</summary>
		public override Color BackColor
		{
			get{ return base.BackColor; }
			set{ base.BackColor = value; }
		}

		[Browsable( false )]
		/// <summary>Obtient ou d�fini la couleur de premier-plan du contr�le (obsol�te)</summary>
		public override Color ForeColor
		{
			get{ return base.ForeColor; }
			set{ base.ForeColor = value; }
		}

		[Browsable( false )]
		/// <summary>Obtient ou d�fini le texte du contr�le (obsol�te)</summary>
		public override string Text
		{
			get{ return base.Text; }
			set{ base.Text = value; }
		}
		#endregion
	}
}
