using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Test
{
	/// <summary>Teste la barre de progression</summary>
	public class Test : System.Windows.Forms.Form
	{
		private Timer _timer;

		/// <summary>Constructeur</summary>
		public Test()
		{
			InitializeComponent();

			_timer = new Timer();
			_timer.Interval = 50;
			_timer.Tick += new EventHandler(_timer_Tick);
		}

		#region Code g�n�r� par le Concepteur Windows Form
		// Contr�les du formulaire
		private LudiProgressBar.LudiProgressBar ludiProgressBar;
		private System.Windows.Forms.Button cmdStart;
		private System.Windows.Forms.Button cmdStop;
		private System.Windows.Forms.Button cmdReset;

		// Variable n�cessaire au concepteur
		private System.ComponentModel.Container components = null;

		// Nettoi les ressources utilis�es
		protected override void Dispose( bool disposing )
		{
			if( disposing && components != null )
					components.Dispose();

			base.Dispose( disposing );
		}

		// M�thode requise pour la prise en charge du concepteur
		private void InitializeComponent()
		{
			this.ludiProgressBar = new LudiProgressBar.LudiProgressBar();
			this.cmdStart = new System.Windows.Forms.Button();
			this.cmdStop = new System.Windows.Forms.Button();
			this.cmdReset = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// ludiProgressBar
			// 
			this.ludiProgressBar.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.ludiProgressBar.BackColor = System.Drawing.Color.Cornsilk;
			this.ludiProgressBar.BackColorGradientAngle = 90F;
			this.ludiProgressBar.BackEndColor = System.Drawing.SystemColors.ControlDark;
			this.ludiProgressBar.BackStartColor = System.Drawing.SystemColors.Control;
			this.ludiProgressBar.BorderColor = System.Drawing.SystemColors.ControlDarkDark;
			this.ludiProgressBar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.ludiProgressBar.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.ludiProgressBar.ForeColor = System.Drawing.SystemColors.ControlDark;
			this.ludiProgressBar.Location = new System.Drawing.Point(8, 8);
			this.ludiProgressBar.MaxValue = 100;
			this.ludiProgressBar.MinValue = 0;
			this.ludiProgressBar.Name = "ludiProgressBar";
			this.ludiProgressBar.ProgressBarColor = System.Drawing.SystemColors.ControlText;
			this.ludiProgressBar.ProgressBarOpacity = 40;
			this.ludiProgressBar.ProgressBarText = "Progression stopp�e (0 %)";
			this.ludiProgressBar.Size = new System.Drawing.Size(232, 32);
			this.ludiProgressBar.TabIndex = 0;
			this.ludiProgressBar.TextColorAfter = System.Drawing.SystemColors.Control;
			this.ludiProgressBar.TextColorBefore = System.Drawing.SystemColors.ControlDarkDark;
			this.ludiProgressBar.Value = 0;
			// 
			// cmdStart
			// 
			this.cmdStart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.cmdStart.Location = new System.Drawing.Point(8, 56);
			this.cmdStart.Name = "cmdStart";
			this.cmdStart.Size = new System.Drawing.Size(72, 24);
			this.cmdStart.TabIndex = 1;
			this.cmdStart.Text = "Start";
			this.cmdStart.Click += new System.EventHandler(this.cmdStart_Click);
			// 
			// cmdStop
			// 
			this.cmdStop.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.cmdStop.Location = new System.Drawing.Point(88, 56);
			this.cmdStop.Name = "cmdStop";
			this.cmdStop.Size = new System.Drawing.Size(72, 24);
			this.cmdStop.TabIndex = 1;
			this.cmdStop.Text = "Stop";
			this.cmdStop.Click += new System.EventHandler(this.cmdStop_Click);
			// 
			// cmdReset
			// 
			this.cmdReset.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.cmdReset.Location = new System.Drawing.Point(168, 56);
			this.cmdReset.Name = "cmdReset";
			this.cmdReset.Size = new System.Drawing.Size(72, 24);
			this.cmdReset.TabIndex = 1;
			this.cmdReset.Text = "Reset";
			this.cmdReset.Click += new System.EventHandler(this.cmdReset_Click);
			// 
			// Test
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(248, 86);
			this.Controls.Add(this.cmdStart);
			this.Controls.Add(this.ludiProgressBar);
			this.Controls.Add(this.cmdStop);
			this.Controls.Add(this.cmdReset);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.MinimumSize = new System.Drawing.Size(256, 112);
			this.Name = "Test";
			this.ShowInTaskbar = false;
			this.Text = "Test - LudiProgressBar -";
			this.TopMost = true;
			this.ResumeLayout(false);

		}

		// Point d'entr�e de l'application
		[STAThread]
		static void Main() 
		{
			Application.Run( new Test() );
		}
		#endregion

		private void cmdStart_Click(object sender, System.EventArgs e)
		{
			_timer.Start();
			ludiProgressBar.ProgressBarText = "Progression en cours (" + ludiProgressBar.Value.ToString() + " %)";
		}

		private void _timer_Tick( object sender, EventArgs e )
		{
			ludiProgressBar.Value ++;
			ludiProgressBar.ProgressBarText = "Progression en cours (" + ludiProgressBar.Value.ToString() + " %)";
		}

		private void cmdStop_Click( object sender, System.EventArgs e )
		{
			_timer.Stop();
			ludiProgressBar.ProgressBarText = "Progression stopp�e (" + ludiProgressBar.Value.ToString() + " %)";
		}

		private void cmdReset_Click( object sender, System.EventArgs e )
		{
			ludiProgressBar.Value = ludiProgressBar.MinValue;

			if( _timer.Enabled )
				ludiProgressBar.ProgressBarText = "Progression en cours (" + ludiProgressBar.Value.ToString() + " %)";
			else
				ludiProgressBar.ProgressBarText = "Progression stopp�e (" + ludiProgressBar.Value.ToString() + " %)";
		}
	}
}
