using System;
using System.Windows.Forms;
using System.IO;
using System.Net;
using System.Drawing;

namespace WindowsApplication24
{
	public class Progressbar : Form
	{
		private ProgressBar ProgressBar1;
		private PictureBox PictureBox1;
		private Button Button1;
		private TextBox TextBox1;

		public Progressbar()
		{
			InitializeComponent();
		}

		private void InitializeComponent()
		{
			this.TextBox1 = new System.Windows.Forms.TextBox();
			this.Button1 = new System.Windows.Forms.Button();
			this.PictureBox1 = new System.Windows.Forms.PictureBox();
			this.ProgressBar1 = new System.Windows.Forms.ProgressBar();
			
			this.TextBox1.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.TextBox1.Location = new System.Drawing.Point(170, 545);
			this.TextBox1.Name = "TextBox1";
			this.TextBox1.Size = new System.Drawing.Size(500, 21);
			this.TextBox1.TabIndex = 1;
			this.TextBox1.Text = "http://www.csharpfr.com/gfx/logos/logocsharp.gif"; // petite image
			
			

			this.Button1.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Button1.Location = new System.Drawing.Point(40, 545);
			this.Button1.Name = "Button1";
			this.Button1.Size = new System.Drawing.Size(113, 21);
			this.Button1.TabIndex = 0;
			this.Button1.Text = "T�l�charger l'image";
			this.Button1.Click += new System.EventHandler(this.Button1_Click);

			this.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.PictureBox1.Location = new System.Drawing.Point(0, 0);
			this.PictureBox1.Name = "PictureBox1";
			this.PictureBox1.Size = new System.Drawing.Size(720, 540);
			this.PictureBox1.TabStop = false;
			
			this.ProgressBar1.Location = new System.Drawing.Point(0, 570);
			this.ProgressBar1.Name = "ProgressBar1";
			this.ProgressBar1.Size = new System.Drawing.Size(720, 30);
			this.ProgressBar1.TabStop = false;

			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(720, 600);
			this.Controls.Add(this.TextBox1);
			this.Controls.Add(this.Button1);
			this.Controls.Add(this.PictureBox1);
			this.Controls.Add(this.ProgressBar1);
			this.Name = "toto";
			this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "T�l�chargement avec ProgressBar";
			this.ResumeLayout(false);
		}

		private void Button1_Click(object sender, System.EventArgs e)
		{
			ProgressBar1.Visible = true;
			ProgressBar1.Minimum = 1;
			ProgressBar1.Value = 1;
			ProgressBar1.Step = 1024;

			MemoryStream MemoryStreamImage = new MemoryStream();

			WebRequest myWebRequest = WebRequest.Create(TextBox1.Text);
			WebResponse myWebResponse = myWebRequest.GetResponse(); 
			ProgressBar1.Maximum = Convert.ToInt32(myWebResponse.ContentLength);
			Stream StreamImage = myWebResponse.GetResponseStream();

			byte[] b = new byte[1024];
			int bytesRead = 0;
	      while ((bytesRead = StreamImage.Read(b, 0, b.Length)) > 0)
	      {
//		      MemoryStreamImage.Write(b, 0, b.Length);
		      MemoryStreamImage.Write(b, 0, bytesRead);
		      ProgressBar1.PerformStep();
			}
			StreamImage.Close();
			PictureBox1.Image = new Bitmap(MemoryStreamImage);
			MemoryStreamImage.Close();
			myWebResponse.Close(); 
		}

		public static void Main()
		{
			Application.Run(new Progressbar() );
		}
	}
}

