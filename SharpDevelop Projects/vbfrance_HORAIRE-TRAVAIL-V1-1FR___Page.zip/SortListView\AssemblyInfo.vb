Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Les informations g�n�rales relatives � un assembly d�pendent de l'ensemble 
' d'attributs suivant. Pour modifier les informations associ�es � un assembly, 
'changez les valeurs de ces attributs.

' V�rifiez les valeurs des attributs de l'assembly

<Assembly: AssemblyTitle("")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("")> 
<Assembly: AssemblyProduct("")> 
<Assembly: AssemblyCopyright("")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: CLSCompliant(True)> 

'Le GUID suivant est pour l'ID de la typelib si ce projet est expos� � COM
<Assembly: Guid("564E1CE9-5D27-41A0-9405-C57AB04D2903")> 

' Les informations de version pour un assembly se composent des quatre valeurs suivantes�:
'
'      Version principale
'      Version secondaire 
'      Num�ro de build
'      R�vision
'
' Vous pouvez sp�cifier toutes les valeurs ou indiquer les num�ros de build et de r�vision par d�faut 
' en utilisant '*', comme indiqu� ci-dessous�:

<Assembly: AssemblyVersion("1.0.*")> 
